import React, { useEffect, useState } from 'react';

const API_URL = 'http://192.168.56.196:5001/productos';
const API_USER_URL = 'http://192.168.56.196:5001/usuarios'; // API para obtener usuario
const API_CART_URL = 'http://192.168.56.196:5001/carrito'; // URL base para carrito

const CrudProductos = () => {
    const [productos, setProductos] = useState([]);
    const [usuario, setUsuario] = useState(null); // Inicializamos como null, porque esperamos un valor de la API
    const [modalVisible, setModalVisible] = useState(false);
    const [editingProducto, setEditingProducto] = useState(null);
    const [formData, setFormData] = useState({ nombre: '', stock: '', precio: '', categoria: '', color: '' });

    useEffect(() => {
        obtener_prod();
        obtener_usuario();
    }, []);

    const obtener_prod = async () => {
        try {
            const response = await fetch(API_URL);
            const data = await response.json();
            // Ordenamos los productos de menor a mayor por ID
            data.sort((a, b) => a.id - b.id);
            setProductos(data);
        } catch (error) {
            console.error('Error al obtener productos', error);
        }
    };

    const obtener_usuario = async () => {
        try {
            const response = await fetch(API_USER_URL); // Este endpoint devuelve todos los usuarios
            const data = await response.json();
            if (data && data.length > 0) {
                setUsuario({ id: data[0].id }); // Asignamos el primer usuario a la variable estado
            } else {
                console.error('No se encontró el usuario');
            }
        } catch (error) {
            console.error('Error al obtener usuario', error);
        }
    };

    const handleAdd = () => {
        setEditingProducto(null);
        setFormData({ nombre: '', stock: '', precio: '', categoria: '', color: '' });
        setModalVisible(true);
    };

    const handleEdit = (producto) => {
        setEditingProducto(producto);
        setFormData(producto);
        setModalVisible(true);
    };

    const handleDelete = async (id) => {
        try {
            await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
            obtener_prod();
        } catch (error) {
            console.error('Error al eliminar producto', error);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const method = editingProducto ? 'PUT' : 'POST';
            const url = editingProducto ? `${API_URL}/${editingProducto.id}` : API_URL;
            await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });
            obtener_prod();
            setModalVisible(false);
        } catch (error) {
            console.error('Error al guardar producto', error);
        }
    };

    const agregarAlCarrito = async (productoId) => {
        const data = {
            producto_id: productoId,
            cantidad: 1,  // Asumiendo que agregas 1 unidad
        };

        try {
            const response = await fetch('http://192.168.56.196:5001/carrito', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });
            const result = await response.json();
            console.log('Producto agregado al carrito:', result);
        } catch (error) {
            console.error('Error al agregar al carrito:', error);
        }
    };

    return (
        <div className="container py-4">
            <button
                className="btn btn-primary mb-4"
                onClick={handleAdd}
            >
                Añadir Producto
            </button>
            {/* Contenedor con desplazamiento horizontal */}
            <div className="table-responsive">
                <table className="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th className="sticky-col">ID</th> {/* Fija la columna ID */}
                            <th>Nombre</th>
                            <th>Stock</th>
                            <th>Precio</th>
                            <th>Categoría</th>
                            <th>Color</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {productos.map((producto) => (
                            <tr key={producto.id}>
                                <td className="sticky-col">{producto.id}</td> {/* Fija la columna ID */}
                                <td>{producto.nombre}</td>
                                <td>{producto.stock}</td>
                                <td>{producto.precio}</td>
                                <td>{producto.categoria}</td>
                                <td>{producto.color}</td>
                                <td>
                                    <button
                                        className="btn btn-warning btn-sm"
                                        onClick={() => handleEdit(producto)}
                                        title="Editar"
                                    >
                                        <i className="fas fa-edit"></i>
                                    </button>
                                    <button
                                        className="btn btn-danger btn-sm mx-2"
                                        onClick={() => handleDelete(producto.id)}
                                        title="Eliminar"
                                    >
                                        <i className="fas fa-trash"></i>
                                    </button>
                                    <button
                                        className="btn btn-success btn-sm"
                                        onClick={() => agregarAlCarrito(producto.id)}
                                        title="Agregar al Carrito"
                                    >
                                        <i className="fas fa-cart-plus"></i>
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {modalVisible && (
                <div className="modal show d-block" style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}>
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title">{editingProducto ? 'Editar Producto' : 'Añadir Producto'}</h5>
                                <button
                                    type="button"
                                    className="close"
                                    onClick={() => setModalVisible(false)}
                                >
                                    <span>&times;</span>
                                </button>
                            </div>
                            <form onSubmit={handleSubmit}>
                                <div className="modal-body">
                                    <div className="form-group">
                                        <label htmlFor="nombre">Nombre</label>
                                        <input
                                            type="text"
                                            id="nombre"
                                            className="form-control"
                                            placeholder="Nombre"
                                            value={formData.nombre}
                                            onChange={(e) =>
                                                setFormData({ ...formData, nombre: e.target.value })
                                            }
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="stock">Stock</label>
                                        <input
                                            type="number"
                                            id="stock"
                                            className="form-control"
                                            placeholder="Stock"
                                            value={formData.stock}
                                            onChange={(e) =>
                                                setFormData({ ...formData, stock: e.target.value })
                                            }
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="precio">Precio</label>
                                        <input
                                            type="number"
                                            id="precio"
                                            className="form-control"
                                            placeholder="Precio"
                                            value={formData.precio}
                                            onChange={(e) =>
                                                setFormData({ ...formData, precio: e.target.value })
                                            }
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="categoria">Categoría</label>
                                        <input
                                            type="text"
                                            id="categoria"
                                            className="form-control"
                                            placeholder="Categoría"
                                            value={formData.categoria}
                                            onChange={(e) =>
                                                setFormData({ ...formData, categoria: e.target.value })
                                            }
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="color">Color</label>
                                        <input
                                            type="text"
                                            id="color"
                                            className="form-control"
                                            placeholder="Color"
                                            value={formData.color}
                                            onChange={(e) =>
                                                setFormData({ ...formData, color: e.target.value })
                                            }
                                        />
                                    </div>
                                </div>
                                <div className="modal-footer">
                                    <button
                                        type="button"
                                        className="btn btn-secondary"
                                        onClick={() => setModalVisible(false)}
                                    >
                                        Cancelar
                                    </button>
                                    <button
                                        type="submit"
                                        className="btn btn-primary"
                                    >
                                        Guardar
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default CrudProductos;
