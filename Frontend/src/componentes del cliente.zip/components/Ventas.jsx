import React, { useState, useEffect } from 'react';

const Ventas = () => {
  const [ventas, setVentas] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Cambia la IP por la IP de tu computadora en la red local
    const fetchVentas = async () => {
      try {
        const response = await fetch('http://192.168.56.196:5001/ventas'); // Reemplaza con la IP de tu computadora
        if (!response.ok) {
          throw new Error('Error al obtener las ventas');
        }
        const data = await response.json();
        setVentas(data); // Guardamos los datos de ventas
      } catch (err) {
        setError(err.message); // Si ocurre un error, lo mostramos
      }
    };

    fetchVentas();
  }, []);

  return (
    <div style={{ padding: '20px', backgroundColor: '#f4f7f9', fontFamily: 'Arial, sans-serif' }}>
      <h1 style={{ textAlign: 'center', color: '#333', marginBottom: '20px' }}>Ventas</h1>
      {error && <p style={{ color: 'red', textAlign: 'center' }}>Error: {error}</p>}
      
      {ventas.length > 0 ? (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '20px' }}>
          {ventas.map((venta) => (
            <div key={venta.id} style={{ 
              backgroundColor: '#ffffff', 
              border: '1px solid #ddd', 
              borderRadius: '8px', 
              padding: '15px', 
              boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
              transition: 'transform 0.3s ease-in-out',
              cursor: 'pointer'
            }}>
              <h3 style={{ fontSize: '18px', fontWeight: '600', color: '#444', marginBottom: '10px' }}>
                Venta ID: {venta.id}
              </h3>
              <div style={{ marginBottom: '15px' }}>
                {venta.productos.map((producto, index) => (
                  <div key={index} style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '10px',
                    padding: '8px',
                    backgroundColor: '#f8f8f8',
                    borderRadius: '6px',
                    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                  }}>
                    <div style={{ fontWeight: '500', color: '#333' }}>{producto.nombre}</div>
                    <div style={{ fontSize: '14px', color: '#888' }}>
                      ${producto.precio} x {producto.cantidad}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p style={{ textAlign: 'center', color: '#888' }}>No hay ventas para mostrar</p>
      )}
    </div>
  );
};

export default Ventas;
