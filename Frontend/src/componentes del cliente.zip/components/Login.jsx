import React, { useState } from 'react';
import { Form, Button, Container, Card, Alert } from 'react-bootstrap';
import MetaBalls from './MetaBalls';


// Función para obtener el usuario desde la API
const obtenerUser = async (credentials) => {
  try {
    const response = await fetch('http://192.168.56.196:5001/usuarios');
    if (!response.ok) {
      throw new Error('Error al obtener usuarios');
    }
    const users = await response.json();

    // Buscar si las credenciales coinciden con algún usuario
    return users.find(u => 
      u.correo === credentials.correo && u.contraseña === credentials.contraseña
    );
  } catch (error) {
    console.error('Error en obtenerUser:', error);
    throw new Error('Error al obtener usuarios');
  }
};

const Login = ({ onLoginSuccess }) => {
  const [credentials, setCredentials] = useState({
    correo: '',
    contraseña: ''
  });
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const user = await obtenerUser(credentials);
      if (user) {
        onLoginSuccess(user);  // Llamamos a la función de éxito
      } else {
        setError('Credenciales inválidas');
      }
    } catch (error) {
      setError('Error al iniciar sesión');
    }
  };
  const MetaBallsComponent = () => {
    return (
      <MetaBalls
        color="#ff85e4"
        cursorBallColor="#ff85e4"
        cursorBallSize={2}
        ballCount={14}
        speed={0.1}
        size={14}
        clumpFactor={0.8}
        enableMouseInteraction={true}
        enableTransparency={true}
        hoverSmoothness={0.05}
        animationSize={30}
      />
    );
  };

  return (
    <Container className="d-flex align-items-center justify-content-center vh-100 position-relative">
      {/* Componente de MetaBalls */}
      <MetaBalls
        color="#ff85e4"
        cursorBallColor="#ff85e4"
        cursorBallSize={2}
        ballCount={14}
        speed={0.1}
        size={14}
        clumpFactor={0.8}
        enableMouseInteraction={true}
        enableTransparency={true}
        hoverSmoothness={0.05}
        animationSize={30}
      />
    
      <Card style={{ width: '300px', zIndex: 1, position: 'absolute', padding: '20px' }}>
        <Card.Body>
          <h2 className="text-center mb-4">Iniciar Sesión</h2>
          {error && <Alert variant="danger">{error}</Alert>}
          <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-4">
              <Form.Control
                type="email"
                placeholder="Correo electrónico"
                value={credentials.correo}
                onChange={(e) => setCredentials({...credentials, correo: e.target.value})}
                required
              />
            </Form.Group>
            <Form.Group className="mb-4">
              <Form.Control
                type="password"
                placeholder="Contraseña"
                value={credentials.contraseña}
                onChange={(e) => setCredentials({...credentials, contraseña: e.target.value})}
                required
              />
            </Form.Group>
            <Button 
              type="submit" 
              className="w-100" 
              style={{
                backgroundColor: '#ff85e4', // Rosa
                color: 'white', 
                border: 'none',
                borderRadius: '8px', 
                padding: '14px 28px', // Aumentar padding para mayor tamaño
                fontSize: '16px',
                cursor: 'pointer',
                transition: 'background-color 0.3s ease, transform 0.2s ease', // Suavizar transición
              }} 
              onMouseOver={(e) => {
                e.target.style.backgroundColor = '#ff69b4'; // Hover color rosa
                e.target.style.transform = 'scale(1.05)'; // Efecto de escala en hover
              }}
              onMouseOut={(e) => {
                e.target.style.backgroundColor = '#ff85e4'; // Revertir color
                e.target.style.transform = 'scale(1)'; // Revertir escala
              }}
            >
              Ingresar
            </Button>
          </Form>
        </Card.Body>
      </Card>
    </Container>
  );
};    
export default Login;
