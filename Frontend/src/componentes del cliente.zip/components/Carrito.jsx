import React, { useState, useEffect } from 'react';
import { Button, List, ListItem, ListItemText, IconButton, Typography, Box } from '@mui/material';
import { ShoppingCart as ShoppingCartIcon } from '@mui/icons-material';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons';

// Funciones para interactuar con la API
const obtenerCarritos = async () => {
  try {
    const response = await fetch('http://192.168.56.196:5001/carrito');
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error al obtener los carritos:', error);
  }
};

const eliminarProducto = async (productoId) => {
  try {
    const response = await fetch(`http://192.168.56.196:5001/carrito/${productoId}`, {
      method: 'DELETE',
    });
    return response.json();
  } catch (error) {
    console.error('Error al eliminar el producto:', error);
  }
};

const crearVenta = async (productos) => {
  try {
    const response = await fetch('http://192.168.56.196:5001/ventas', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ productos }), // Enviar los productos como parte de la venta
    });
    const data = await response.json();
    console.log('Venta creada:', data);
    return data;
  } catch (error) {
    console.error('Error al crear la venta:', error);
  }
};

const Carrito = () => {
  const [productosCarrito, setProductosCarrito] = useState([]);

  useEffect(() => {
    cargarCarrito();
  }, []);

  const cargarCarrito = async () => {
    const carritos = await obtenerCarritos();
    setProductosCarrito(carritos);
  };

  const manejarEliminarProducto = async (productoId) => {
    await eliminarProducto(productoId);
    cargarCarrito();
  };

  const manejarProcederPago = async () => {
    if (productosCarrito.length === 0) {
      alert('El carrito está vacío');
      return;
    }

    // Crear la venta con los productos actuales
    const productos = productosCarrito.map((producto) => ({
      nombre: producto.productos.nombre,
      cantidad: producto.cantidad,
      precio: producto.productos.precio,
    }));

    const venta = await crearVenta(productos);
    if (venta) {
      alert('Venta realizada con éxito');
      // Aquí podrías limpiar el carrito o redirigir a otra página
    }
  };

  return (
    <Box sx={{ padding: 2, backgroundColor: '#f5f5f5', borderRadius: 2 }}>
      <Typography variant="h4" component="h1" sx={{ textAlign: 'center', marginBottom: 2 }}>
        <ShoppingCartIcon sx={{ verticalAlign: 'middle', marginRight: 1 }} />
        Carrito de Compras
      </Typography>

      <Typography variant="h6" sx={{ marginBottom: 2 }}>
        Productos actuales
      </Typography>
      <List>
        {productosCarrito.length > 0 ? (
          productosCarrito.map((producto) => (
            <ListItem
              key={producto.id}
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                backgroundColor: '#fff',
                padding: 1.5,
                borderRadius: 1,
                marginBottom: 1,
                boxShadow: 1,
              }}
            >
              <ListItemText
                primary={producto.productos.nombre} // Nombre del producto
                secondary={`Cantidad: ${producto.cantidad} - Precio: $${producto.productos.precio}`} 
                sx={{ flex: 1 }}
              />
              <IconButton
                onClick={() => manejarEliminarProducto(producto.id)}
                sx={{
                  color: '#f44336',
                  '&:hover': {
                    backgroundColor: '#ffdede',
                  },
                }}
              >
                <FontAwesomeIcon icon={faTrashAlt} size="lg" />
              </IconButton>
            </ListItem>
          ))
        ) : (
          <Typography variant="body1" sx={{ textAlign: 'center', color: '#888' }}>
            No hay productos en el carrito.
          </Typography>
        )}
      </List>

      <Box sx={{ textAlign: 'center', marginTop: 2 }}>
        <Button
          variant="contained"
          color="primary"
          size="large"
          onClick={manejarProcederPago} // Llamada a la función para proceder al pago
          sx={{
            borderRadius: 16,
            padding: '10px 20px',
            textTransform: 'none',
            fontSize: '1rem',
            boxShadow: 3,
          }}
        >
          Proceder al Pago
        </Button>
      </Box>
    </Box>
  );
};

export default Carrito;
